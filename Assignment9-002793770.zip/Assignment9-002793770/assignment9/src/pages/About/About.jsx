import React from "react";
import Card from "../../components/Card";
import Navbar from "../../components/Navbar";
import "./about.css";
const About = () => {
  return (
    <div className="container">
      <Navbar />
      <Card
        header={"About"}
        cardContent={
          "NUworks is Northeastern University’s career management portal for sharing career, cooperative education (co-op), internship, and XN opportunities with current students at all levels, including PhDs as well as recent alumni"
        }
      />
    </div>
  );
};

export default About;
