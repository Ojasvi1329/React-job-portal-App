import React from "react";
import Card from "../../components/Card";
import Navbar from "../../components/Navbar";
import "./job.css";
const Job = () => {
  const jobs = [
    {
      id: 1,
      title: "SDE",
      description: "Software Development Engineer",
    },
    {
      id: 2,
      title: "Backend Developer",
      description: "Creating, maintaining, testing, and debugging the entire back end of an application or system",
    },
    {
      id: 3,
      title: "Front end Developer",
      description: "Determining the structure and design of web pages, building reusable codes, optimizing page loading times",
    },
    {
      id: 4,
      title: "Data analytics",
      description: "Examining data sets in order to find trends and draw conclusions about the information they contain",
    },
  ];
  return (
    <div className="container">
      <Navbar />
      <div className="jobs_container">
        {jobs.map((job) => (
          <Card
            key={job.id}
            header={job.title}
            cardContent={job.description}
            isShowButton
          />
        ))}
      </div>
    </div>
  );
};

export default Job;
