import React from "react";
import Card from "../../components/Card";
import Navbar from "../../components/Navbar";

const Home = () => {
  return (
    <div className="container">
      <Navbar />
      <Card
        header={"Welcome to Nuworks"}
        cardContent={
          "This is a job board for finding coop opportunties at Northeastern University"
        }
      />
    </div>
  );
};

export default Home;
